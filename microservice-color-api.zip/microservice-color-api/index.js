const express = require('express');
const cors = require('cors');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

let colors = [
  { id: 1, name: 'Red' },
  { id: 2, name: 'Green' },
  { id: 3, name: 'Blue' }
];

// GET
app.get('/colors', (req, res) => {
  res.json(colors);
});

// POST
app.post('/colors', (req, res) => {
  const newColor = { id: Date.now(), name: req.body.name };
  colors.push(newColor);
  res.status(201).json(newColor);
});

// PUT
app.put('/colors/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const color = colors.find(c => c.id === id);
  if (color) {
    color.name = req.body.name;
    res.json(color);
  } else {
    res.status(404).json({ message: 'Color not found' });
  }
});

// DELETE
app.delete('/colors/:id', (req, res) => {
  const id = parseInt(req.params.id);
  colors = colors.filter(c => c.id !== id);
  res.status(204).end();
});

app.listen(port, () => {
  console.log(`Color API listening at http://localhost:${port}`);
});
