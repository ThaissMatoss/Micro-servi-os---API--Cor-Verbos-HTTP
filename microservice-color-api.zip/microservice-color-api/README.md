# 🎨 Microservice - Color API

API RESTful simples para demonstrar o uso de verbos HTTP e CORS em um microserviço com Node.js e Express.

## 🔥 Como rodar

```bash
npm install
npm start
```

## 🚀 Teste com:
- `GET http://localhost:3000/colors`
- `POST`, `PUT`, `DELETE` com JSON: `{ "name": "Yellow" }`

---
